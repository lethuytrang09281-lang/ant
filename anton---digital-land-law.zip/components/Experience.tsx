import React from 'react';

export const Experience: React.FC = () => {
  return (
    <section id="Experience" className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          <div className="lg:col-span-5 space-y-12">
            <div className="space-y-4">
              <div className="text-[10px] font-bold text-accent uppercase tracking-[0.5em]">Our Approach</div>
              <h2 className="text-4xl md:text-6xl font-serif text-white uppercase italic leading-none">
                Elite <br />Expertise
              </h2>
            </div>
            
            <p className="text-slate-400 text-lg leading-relaxed border-l border-accent pl-8">
              We specialize in land law with a technical rigor that others can't match. Every case is treated as an architectural project—built on facts, fortified by law.
            </p>
            
            <div className="grid grid-cols-1 gap-12">
               <div className="group">
                  <div className="text-3xl font-light text-white mb-2 group-hover:text-accent transition-colors">15+</div>
                  <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Years of Practice</div>
               </div>
               <div className="group">
                  <div className="text-3xl font-light text-white mb-2 group-hover:text-accent transition-colors">450+</div>
                  <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Won Litigations</div>
               </div>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 gap-1">
             {[
               { tag: 'Boundary Dispute', title: 'Resolving Overlap of 12 Plots', result: '₽2.4M Saved' },
               { tag: 'Development', title: 'Warehouse Complex Legalization', result: '3,500 sq.m Saved' },
               { tag: 'Taxation', title: 'Tax Reduction for Shopping Mall', result: '40% Reduction' }
             ].map((item, i) => (
               <div key={i} className="bg-white/2 border border-white/5 p-10 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-white/5 transition-colors cursor-default">
                 <div className="space-y-3">
                   <div className="text-[9px] font-bold text-accent uppercase tracking-[0.3em]">{item.tag}</div>
                   <h4 className="text-xl font-light text-white uppercase tracking-tight">{item.title}</h4>
                 </div>
                 <div className="text-sm font-bold text-white uppercase border border-white/10 px-4 py-2 rounded">
                   {item.result}
                 </div>
               </div>
             ))}
          </div>

        </div>
      </div>
    </section>
  );
};