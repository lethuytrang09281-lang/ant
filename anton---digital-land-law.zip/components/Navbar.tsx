
import React from 'react';
import { Cpu } from 'lucide-react';

export const Navbar: React.FC = () => {
  return (
    <nav className="absolute top-0 w-full z-[100] py-10 px-6 lg:px-24">
      <div className="max-w-[1440px] mx-auto flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 border border-white/20 flex items-center justify-center">
            <Cpu size={14} className="text-[#ff4d3d]" />
          </div>
          <span className="text-2xl font-black tracking-tighter uppercase text-white">
            Terra<span className="text-[#ff4d3d]">lex</span>
          </span>
        </div>

        <div className="hidden md:flex items-center gap-10">
          {['Home', 'Legal Practice', 'Blog', 'Pages', 'Contacts'].map((item) => (
            <a 
              key={item} 
              href={`#${item.replace(' ', '')}`} 
              className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-400 hover:text-white transition-colors"
            >
              {item}
            </a>
          ))}
        </div>

        <div className="flex flex-col gap-1 items-end cursor-pointer group">
          <div className="w-8 h-[2px] bg-white group-hover:w-10 transition-all"></div>
          <div className="w-10 h-[2px] bg-white group-hover:w-8 transition-all"></div>
        </div>
      </div>
    </nav>
  );
};
