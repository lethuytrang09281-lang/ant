import React from 'react';
import { ArrowRight, Send } from 'lucide-react';

export const ContactSection: React.FC = () => {
  return (
    <section id="Contact" className="py-24 bg-black border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2">
          
          <div className="p-8 md:p-20 border border-white/5 bg-white/[0.01]">
            <div className="w-12 h-[1px] bg-accent mb-8"></div>
            <h2 className="text-4xl md:text-6xl font-serif text-white mb-10 uppercase italic leading-none">
              Get an <br />Audit
            </h2>
            <p className="text-slate-500 mb-12 uppercase tracking-widest text-xs font-bold leading-loose">
              Send us your cadastral number and a brief description of the issue. Our team will provide a preliminary analysis within 24 hours.
            </p>
            
            <form className="space-y-12">
              <div className="space-y-8">
                <input type="text" className="w-full bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-accent transition-colors placeholder:text-slate-700 font-light text-lg" placeholder="NAME" />
                <input type="tel" className="w-full bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-accent transition-colors placeholder:text-slate-700 font-light text-lg" placeholder="PHONE" />
                <textarea rows={3} className="w-full bg-transparent border-b border-white/10 py-4 text-white focus:outline-none focus:border-accent transition-colors placeholder:text-slate-700 font-light text-lg resize-none" placeholder="CASE DETAILS (CADASTRAL NUMBER)"></textarea>
              </div>
              <button className="group flex items-center gap-4 text-accent text-sm font-bold uppercase tracking-[0.4em] hover:text-white transition-colors">
                Send Request <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
              </button>
            </form>
          </div>
          
          <div className="p-8 md:p-20 border-y border-r border-white/5 flex flex-col justify-between">
            <div className="space-y-16">
              <div>
                <h3 className="text-[10px] font-bold text-accent uppercase tracking-[0.5em] mb-8">Direct Lines</h3>
                <div className="space-y-10">
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Phone</p>
                    <p className="text-2xl font-light text-white">+7 (495) 123-45-67</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Email</p>
                    <p className="text-2xl font-light text-white underline decoration-accent/30 underline-offset-8">law@terralex.digital</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Address</p>
                    <p className="text-xl font-light text-white max-w-xs">Moscow City, OKO Tower, 45th Floor</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-20 pt-12 border-t border-white/5">
              <p className="text-xs text-slate-500 leading-relaxed uppercase tracking-widest font-bold">
                "Land is an asset that demands legal precision, not compromise."
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};