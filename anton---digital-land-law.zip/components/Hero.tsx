
import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[85vh] flex flex-col justify-center px-6 lg:px-24 pt-32 pb-16">
      <div className="max-w-[1440px] mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-end">
        
        {/* Left Side: Law Firm Title */}
        <div className="space-y-16">
          <h1 className="text-[120px] md:text-[180px] font-extrabold leading-[0.85] tracking-tight-custom text-white uppercase">
            Law<br />Firm
          </h1>
          
          <div className="flex items-start gap-4 max-w-sm">
            <div className="w-12 h-[1px] bg-white/40 mt-3 flex-shrink-0"></div>
            <p className="text-slate-400 text-sm leading-relaxed font-medium uppercase tracking-widest">
              Providing expert legal services in land, property, and complex cadastral disputes. Precision is our core value.
            </p>
          </div>
        </div>

        {/* Right Side: Solving any problem */}
        <div className="lg:pl-20">
          <h2 className="text-6xl md:text-[90px] font-medium leading-[0.9] tracking-tight text-white mb-20 max-w-lg">
            solving <br />
            any <br />
            problem
          </h2>
        </div>
      </div>
    </section>
  );
};
