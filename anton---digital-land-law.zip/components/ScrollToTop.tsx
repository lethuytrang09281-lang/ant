import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export const ScrollToTop: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  // Show button when page is scrolled down
  const toggleVisibility = () => {
    if (window.pageYOffset > 400) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  return (
    <div className={`fixed bottom-8 right-8 z-50 transition-all duration-500 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0 pointer-events-none'}`}>
      <button
        onClick={scrollToTop}
        className="group relative flex items-center justify-center w-12 h-12 bg-black/40 backdrop-blur-md border border-white/10 hover:border-accent/50 transition-all duration-300 shadow-2xl overflow-hidden"
        aria-label="Scroll to top"
      >
        {/* Animated background fill on hover */}
        <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-300 opacity-20"></div>
        
        {/* Tech decorative corners */}
        <div className="absolute top-0 left-0 w-1 h-1 border-t border-l border-accent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <div className="absolute bottom-0 right-0 w-1 h-1 border-b border-r border-accent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        <ArrowUp 
          size={20} 
          className="text-white group-hover:text-accent transition-colors duration-300 group-hover:-translate-y-1" 
        />
        
        {/* Subtle geometric lines */}
        <div className="absolute -bottom-1 left-0 w-full h-[1px] bg-accent/30 scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
      </button>
      
      {/* Label for the button */}
      <span className="absolute -left-12 top-1/2 -translate-y-1/2 vertical-text text-[8px] uppercase tracking-widest text-slate-600 font-bold opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Top
      </span>
    </div>
  );
};
