
import React from 'react';

const SERVICES_DATA = [
  {
    num: '01',
    title: 'Civil Litigation',
    desc: 'Deep analytical approach to every courtroom battle.'
  },
  {
    num: '02',
    title: 'Insurance Defense',
    desc: 'Protecting your assets with technical legal rigor.'
  },
  {
    num: '03',
    title: 'Real Estate Law',
    desc: 'Comprehensive land law solutions for global entities.'
  },
  {
    num: '04',
    title: 'Intellectual Property',
    desc: 'Safeguarding digital and territorial rights.'
  }
];

export const Services: React.FC = () => {
  return (
    <section id="Services" className="px-6 lg:px-24 pb-24">
      <div className="max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-1">
          {SERVICES_DATA.map((service, idx) => (
            <div 
              key={idx} 
              className="bg-[#1a1a1a] p-12 min-h-[320px] flex flex-col justify-between transition-all duration-500 hover:bg-[#222222] group cursor-pointer"
            >
              <div>
                <span className="text-[10px] font-bold text-[#ff4d3d] uppercase tracking-[0.4em] mb-8 block">
                  {service.num}
                </span>
                <h3 className="text-3xl font-bold text-white leading-tight uppercase tracking-tight">
                  {service.title}
                </h3>
              </div>
              
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <p className="text-[10px] text-slate-500 uppercase tracking-widest leading-loose">
                  {service.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
