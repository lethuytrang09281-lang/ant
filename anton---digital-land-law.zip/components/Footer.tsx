import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start gap-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 border border-accent flex items-center justify-center">
                <div className="w-2 h-2 bg-accent"></div>
              </div>
              <span className="text-xl font-bold text-white tracking-tighter uppercase">Terra<span className="text-accent">lex</span></span>
            </div>
            <p className="text-[10px] text-slate-600 uppercase tracking-[0.2em] font-bold max-w-xs leading-loose">
              High-performance legal architecture for land and real estate management.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-16">
            <div className="space-y-6">
               <h4 className="text-[10px] text-white uppercase tracking-[0.3em] font-bold">Legal</h4>
               <ul className="space-y-4 text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                 <li><a href="#" className="hover:text-accent transition-colors">Privacy Policy</a></li>
                 <li><a href="#" className="hover:text-accent transition-colors">Terms of Service</a></li>
                 <li><a href="#" className="hover:text-accent transition-colors">Regulatory Docs</a></li>
               </ul>
            </div>
            <div className="space-y-6">
               <h4 className="text-[10px] text-white uppercase tracking-[0.3em] font-bold">Social</h4>
               <ul className="space-y-4 text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                 <li><a href="#" className="hover:text-accent transition-colors">Telegram</a></li>
                 <li><a href="#" className="hover:text-accent transition-colors">LinkedIn</a></li>
                 <li><a href="#" className="hover:text-accent transition-colors">Behance</a></li>
               </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[9px] text-slate-700 uppercase tracking-[0.4em] font-bold">
          <p>© 2024 TERRALEX DIGITAL. BUILT FOR PRECISION.</p>
          <p>MOSCOW / DUBAI / LONDON</p>
        </div>
      </div>
    </footer>
  );
};